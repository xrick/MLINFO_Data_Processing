// Data cleaning application JavaScript

class DataCleaner {
    constructor() {
        this.sampleData = `[Stage & Version Information]

- MP Version:
  - AG958: v1.1
  - AG958V: v1.0
  - AG958P: v1.0
  - APX958: v1.0
  - AHP958: v1.0

[Model Information]

- Model Names:
  - AG958
  - AG958V
  - AG958P
  - APX958
  - AHP958

[Board Versions]

- MB Version:
  - AG958: v3.0
  - AG958V: v2.0
  - AG958P: v2.0
  - APX958: v2.0
  - AHP958: v1.0

[Development Timeline]

- Kick-off Dates:
  - AG958: 2022/09/30
  - AG958V: 2022/03/06
  - AG958P: 2022/10/11
  - APX958: 2022/12/19
  - AHP958: 2023/08/31

[PM Ownership]

- Project Owner: Jerry

[Structure Configuration]

- Form Factor: Gaming Notebook
- Dimensions:
  - AG958: 367.6 × 265.9 × 19.9 mm
  - AG958V: 367.6 × 265.9 × 19.9 mm
  - AG958P: 367.6 × 265.9 × 21.9 mm

[LCD]

- Display Sizes: 15.6 16:9 / 16.1 16:9
- Resolutions: FHD 1920×1080, 144Hz

[CPU]

- AG958 / AG958V:
  - Ryzen™ 5 6600H (6C/12T, 4.5GHz/3.3GHz, TDP: 45W)
  - Ryzen™ 7 6800H (8C/16T, 4.7GHz/3.2GHz, TDP: 45W)

- AG958P:
  - Ryzen™ 5 7535HS (6C/12T, 4.55GHz/3.3GHz, TDP: 35W~54W)
  - Ryzen™ 7 7735HS (8C/16T, 4.75GHz/3.2GHz, TDP: 35W~54W)

[GPU]

- AG958:
  - AMD Radeon™ RX6550M, 8GB GDDR6
- AG958V:
  - AMD Radeon™ RX6500M, 4GB GDDR6
- AG958P:
  - AMD Radeon™ RX7600M, 8GB GDDR6

[Memory]

- AG958 / AG958V / AG958P:
  - 2 × DDR5 SO-DIMM, up to 32GB DDR5 4800MHz

[Storage]

- All models:
  - 2 × M.2 2280 PCIe Gen4 NVMe SSD

[Thermal Solution]

- AG958: 110W
- AG958V: 70W
- AG958P: 150W

[Software Configuration]

- Operating System: Windows 11 SV2 (23H2)

[Accessory]

- AG958: 230W Power Adapter
- AG958V: 180W Power Adapter
- AG958P: 230W Power Adapter`;

        this.fieldNames = [
            'modeltype', 'version', 'modelname', 'mainboard', 'devtime',
            'pm', 'structconfig', 'lcd', 'touchpanel', 'iointerface',
            'ledind', 'powerbutton', 'keyboard', 'webcamera', 'touchpad',
            'fingerprint', 'audio', 'battery', 'cpu', 'gpu', 'memory',
            'lcdconnector', 'storage', 'wifislot', 'thermal', 'tpm', 'rtc',
            'wireless', 'lan', 'bluetooth', 'softwareconfig', 'ai', 'accessory',
            'certifications', 'otherfeatures'
        ];

        this.fieldLabels = {
            modeltype: '產品類型',
            version: '版本號',
            modelname: '模型名稱',
            mainboard: '主機板版本',
            devtime: '開發時間',
            pm: '專案經理',
            structconfig: '結構配置',
            lcd: '液晶顯示器',
            touchpanel: '觸控面板',
            iointerface: '輸入輸出介面',
            ledind: 'LED指示燈',
            powerbutton: '電源按鈕',
            keyboard: '鍵盤',
            webcamera: '網路攝影機',
            touchpad: '觸控板',
            fingerprint: '指紋辨識',
            audio: '音訊',
            battery: '電池',
            cpu: '中央處理器',
            gpu: '圖形處理器',
            memory: '記憶體',
            lcdconnector: 'LCD連接器',
            storage: '儲存裝置',
            wifislot: 'WiFi插槽',
            thermal: '散熱解決方案',
            tpm: 'TPM',
            rtc: '即時時鐘',
            wireless: '無線網路',
            lan: '有線網路',
            bluetooth: '藍芽',
            softwareconfig: '軟體配置',
            ai: 'AI功能',
            accessory: '配件',
            certifications: '認證',
            otherfeatures: '其他功能'
        };

        this.extractedData = [];
        this.filteredData = [];
        this.init();
    }

    init() {
        this.bindEvents();
        this.setupDragAndDrop();
    }

    bindEvents() {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });

        // File input
        document.getElementById('fileInput').addEventListener('change', (e) => {
            this.handleFileSelect(e.target.files[0]);
        });

        // Load sample data
        document.getElementById('loadSampleBtn').addEventListener('click', () => {
            this.loadSampleData();
        });

        // Process data
        document.getElementById('processBtn').addEventListener('click', () => {
            this.processData();
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.filterData(e.target.value);
        });

        // Download CSV
        document.getElementById('downloadBtn').addEventListener('click', () => {
            this.downloadCSV();
        });
    }

    setupDragAndDrop() {
        const uploadArea = document.querySelector('.file-upload-area');
        
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleFileSelect(files[0]);
            }
        });
    }

    switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`).classList.add('active');
    }

    handleFileSelect(file) {
        if (!file) return;

        if (file.type !== 'text/plain') {
            this.showError('請選擇 .txt 格式的檔案');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('textInput').value = e.target.result;
            this.switchTab('text');
            document.querySelector('.file-upload-area').classList.add('file-selected');
            this.showSuccess(`已載入檔案: ${file.name}`);
        };
        reader.readAsText(file);
    }

    loadSampleData() {
        document.getElementById('textInput').value = this.sampleData;
        this.switchTab('text');
        this.showSuccess('範例資料已載入');
    }

    processData() {
        const textInput = document.getElementById('textInput').value.trim();
        
        if (!textInput) {
            this.showError('請輸入或上傳技術規格文件');
            return;
        }

        this.showStatus('正在處理資料...');
        
        // Simulate processing delay
        setTimeout(() => {
            try {
                this.extractedData = this.parseData(textInput);
                this.filteredData = [...this.extractedData];
                this.displayResults();
                this.hideStatus();
            } catch (error) {
                this.hideStatus();
                this.showError('資料處理失敗: ' + error.message);
            }
        }, 1000);
    }

    parseData(text) {
        const models = this.extractModels(text);
        const results = [];

        models.forEach(model => {
            const modelData = this.extractModelData(text, model);
            results.push(modelData);
        });

        return results;
    }

    extractModels(text) {
        const modelPattern = /- Model Names:\s*\n((?:\s*- \w+\n?)+)/;
        const match = text.match(modelPattern);
        
        if (!match) {
            // Fallback: extract from various sections
            const modelSet = new Set();
            const patterns = [
                /- (\w+):/g,
                /(\w+): v\d+\.\d+/g,
                /(\w+): \d{4}\/\d{2}\/\d{2}/g
            ];

            patterns.forEach(pattern => {
                let match;
                while ((match = pattern.exec(text)) !== null) {
                    const modelName = match[1];
                    if (modelName && modelName.match(/^[A-Z]+\d+[A-Z]*$/)) {
                        modelSet.add(modelName);
                    }
                }
            });

            return Array.from(modelSet);
        }

        return match[1].split('\n')
            .map(line => line.trim().replace(/^- /, ''))
            .filter(line => line.length > 0);
    }

    extractModelData(text, modelName) {
        const data = {
            modelname: modelName,
            modeltype: this.extractModelType(text),
            version: this.extractVersion(text, modelName),
            mainboard: this.extractMainboard(text, modelName),
            devtime: this.extractDevTime(text, modelName),
            pm: this.extractPM(text),
            structconfig: this.extractStructConfig(text, modelName),
            lcd: this.extractLCD(text),
            touchpanel: '',
            iointerface: '',
            ledind: '',
            powerbutton: '',
            keyboard: '',
            webcamera: '',
            touchpad: '',
            fingerprint: '',
            audio: '',
            battery: '',
            cpu: this.extractCPU(text, modelName),
            gpu: this.extractGPU(text, modelName),
            memory: this.extractMemory(text, modelName),
            lcdconnector: '',
            storage: this.extractStorage(text, modelName),
            wifislot: '',
            thermal: this.extractThermal(text, modelName),
            tpm: '',
            rtc: '',
            wireless: '',
            lan: '',
            bluetooth: '',
            softwareconfig: this.extractSoftwareConfig(text),
            ai: '',
            accessory: this.extractAccessory(text, modelName),
            certifications: '',
            otherfeatures: ''
        };

        return data;
    }

    extractModelType(text) {
        const pattern = /Form Factor:\s*([^\n]+)/;
        const match = text.match(pattern);
        return match ? match[1].trim() : '';
    }

    extractVersion(text, modelName) {
        const pattern = new RegExp(`- ${modelName}:\\s*v([\\d.]+)`, 'i');
        const match = text.match(pattern);
        return match ? `v${match[1]}` : '';
    }

    extractMainboard(text, modelName) {
        const pattern = new RegExp(`- ${modelName}:\\s*v([\\d.]+)`, 'i');
        const mbSection = text.match(/\[Board Versions\]([\s\S]*?)(?=\[|$)/);
        if (mbSection) {
            const match = mbSection[1].match(pattern);
            return match ? `v${match[1]}` : '';
        }
        return '';
    }

    extractDevTime(text, modelName) {
        const pattern = new RegExp(`- ${modelName}:\\s*(\\d{4}\\/\\d{2}\\/\\d{2})`, 'i');
        const match = text.match(pattern);
        return match ? match[1] : '';
    }

    extractPM(text) {
        const pattern = /Project Owner:\s*([^\n]+)/;
        const match = text.match(pattern);
        return match ? match[1].trim() : '';
    }

    extractStructConfig(text, modelName) {
        const pattern = new RegExp(`- ${modelName}:\\s*([\\d.]+\\s*×\\s*[\\d.]+\\s*×\\s*[\\d.]+\\s*mm)`, 'i');
        const match = text.match(pattern);
        return match ? match[1] : '';
    }

    extractLCD(text) {
        const pattern = /Display Sizes:\s*([^\n]+)/;
        const match = text.match(pattern);
        let result = match ? match[1].trim() : '';
        
        const resPattern = /Resolutions:\s*([^\n]+)/;
        const resMatch = text.match(resPattern);
        if (resMatch) {
            result += `, ${resMatch[1].trim()}`;
        }
        
        return result;
    }

    extractCPU(text, modelName) {
        const cpuSection = text.match(/\[CPU\]([\s\S]*?)(?=\[|$)/);
        if (!cpuSection) return '';

        const modelPattern = new RegExp(`- ${modelName}[\\s\\S]*?(?=- \\w+:|$)`, 'i');
        const match = cpuSection[1].match(modelPattern);
        if (match) {
            return match[0].replace(/^- \w+[^:]*:?\s*/, '').trim();
        }

        // Check for shared CPU info
        const sharedPattern = new RegExp(`- ${modelName}\\s*\\/[\\s\\S]*?(?=- \\w+:|$)`, 'i');
        const sharedMatch = cpuSection[1].match(sharedPattern);
        if (sharedMatch) {
            return sharedMatch[0].replace(/^- [^:]*:?\s*/, '').trim();
        }

        return '';
    }

    extractGPU(text, modelName) {
        const gpuSection = text.match(/\[GPU\]([\s\S]*?)(?=\[|$)/);
        if (!gpuSection) return '';

        const pattern = new RegExp(`- ${modelName}:\\s*([^\\n]+)`, 'i');
        const match = gpuSection[1].match(pattern);
        return match ? match[1].trim() : '';
    }

    extractMemory(text, modelName) {
        const memorySection = text.match(/\[Memory\]([\s\S]*?)(?=\[|$)/);
        if (!memorySection) return '';

        const pattern = new RegExp(`- ${modelName}[\\s\\S]*?([^\\n]+)`, 'i');
        const match = memorySection[1].match(pattern);
        if (match) {
            return match[1].trim();
        }

        // Check for shared memory info
        const sharedPattern = /- [^:]*:\s*([^\n]+)/;
        const sharedMatch = memorySection[1].match(sharedPattern);
        return sharedMatch ? sharedMatch[1].trim() : '';
    }

    extractStorage(text, modelName) {
        const storageSection = text.match(/\[Storage\]([\s\S]*?)(?=\[|$)/);
        if (!storageSection) return '';

        const pattern = /- All models:\s*([^\n]+)/;
        const match = storageSection[1].match(pattern);
        return match ? match[1].trim() : '';
    }

    extractThermal(text, modelName) {
        const thermalSection = text.match(/\[Thermal Solution\]([\s\S]*?)(?=\[|$)/);
        if (!thermalSection) return '';

        const pattern = new RegExp(`- ${modelName}:\\s*([^\\n]+)`, 'i');
        const match = thermalSection[1].match(pattern);
        return match ? match[1].trim() : '';
    }

    extractSoftwareConfig(text) {
        const pattern = /Operating System:\s*([^\n]+)/;
        const match = text.match(pattern);
        return match ? match[1].trim() : '';
    }

    extractAccessory(text, modelName) {
        const accessorySection = text.match(/\[Accessory\]([\s\S]*?)(?=\[|$)/);
        if (!accessorySection) return '';

        const pattern = new RegExp(`- ${modelName}:\\s*([^\\n]+)`, 'i');
        const match = accessorySection[1].match(pattern);
        return match ? match[1].trim() : '';
    }

    displayResults() {
        const resultsSection = document.getElementById('resultsSection');
        const tableHeader = document.getElementById('tableHeader');
        const tableBody = document.getElementById('tableBody');

        // Show results section
        resultsSection.classList.remove('hidden');

        // Build table header
        tableHeader.innerHTML = '';
        this.fieldNames.forEach(field => {
            const th = document.createElement('th');
            th.textContent = this.fieldLabels[field];
            tableHeader.appendChild(th);
        });

        // Build table body
        this.updateTableBody();

        // Update row count
        document.getElementById('rowCount').textContent = `共 ${this.filteredData.length} 個模型`;
    }

    updateTableBody() {
        const tableBody = document.getElementById('tableBody');
        tableBody.innerHTML = '';

        this.filteredData.forEach(row => {
            const tr = document.createElement('tr');
            
            this.fieldNames.forEach(field => {
                const td = document.createElement('td');
                td.textContent = row[field] || '';
                if (field === 'modelname') {
                    td.classList.add('model-name');
                }
                tr.appendChild(td);
            });

            tableBody.appendChild(tr);
        });
    }

    filterData(searchTerm) {
        const term = searchTerm.toLowerCase();
        this.filteredData = this.extractedData.filter(row => {
            return Object.values(row).some(value => 
                value.toLowerCase().includes(term)
            );
        });
        
        this.updateTableBody();
        document.getElementById('rowCount').textContent = `共 ${this.filteredData.length} 個模型`;
    }

    downloadCSV() {
        if (this.filteredData.length === 0) {
            this.showError('沒有資料可以下載');
            return;
        }

        const headers = this.fieldNames.map(field => this.fieldLabels[field]);
        const csvContent = [
            headers.join(','),
            ...this.filteredData.map(row => 
                this.fieldNames.map(field => `"${row[field] || ''}"`).join(',')
            )
        ].join('\n');

        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `技術規格資料_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
    }

    showStatus(message) {
        const statusSection = document.getElementById('statusSection');
        const statusText = document.getElementById('statusText');
        statusText.textContent = message;
        statusSection.classList.remove('hidden');
    }

    hideStatus() {
        document.getElementById('statusSection').classList.add('hidden');
    }

    showError(message) {
        this.removeMessages();
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        document.querySelector('.input-section .card__body').appendChild(errorDiv);
        
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }

    showSuccess(message) {
        this.removeMessages();
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message';
        successDiv.textContent = message;
        document.querySelector('.input-section .card__body').appendChild(successDiv);
        
        setTimeout(() => {
            successDiv.remove();
        }, 3000);
    }

    removeMessages() {
        const messages = document.querySelectorAll('.error-message, .success-message');
        messages.forEach(msg => msg.remove());
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new DataCleaner();
});